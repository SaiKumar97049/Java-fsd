package SaiKumarNaik;

import java.util.Stack;

public class StackExample {

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Inserting (pushing) elements into the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        System.out.println("Stack after pushing elements: " + stack);

        // Removing (popping) elements from the stack
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);
        System.out.println("Stack after popping element: " + stack);

        // Inserting (pushing) one more element
        stack.push(50);
        System.out.println("Stack after pushing one more element: " + stack);
    }
}
