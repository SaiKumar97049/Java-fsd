package SaiKumarNaik;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {

    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Inserting (enqueuing) elements into the queue
        queue.offer(10);
        queue.offer(20);
        queue.offer(30);
        queue.offer(40);

        System.out.println("Queue after enqueuing elements: " + queue);

        // Removing (dequeuing) elements from the queue
        int dequeuedElement = queue.poll();
        System.out.println("Dequeued element: " + dequeuedElement);
        System.out.println("Queue after dequeuing element: " + queue);

        // Inserting (enqueuing) one more element
        queue.offer(50);
        System.out.println("Queue after enqueuing one more element: " + queue);
    }
}
