package RightRotateArray;

public class RightRotateArray {

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int steps = 5;

        rightRotate(arr, steps);

        System.out.println("Rotated Array:");
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }

    public static void rightRotate(int[] arr, int steps) {
        int length = arr.length;
        steps = steps % length; // Handle cases where steps > length

        // Create a temporary array to store elements to be shifted
        int[] temp = new int[steps];

        // Copy the last 'steps' elements to temp array
        for (int i = 0; i < steps; i++) {
            temp[i] = arr[length - steps + i];
        }

        // Shift the elements to the right
        for (int i = length - 1; i >= steps; i--) {
            arr[i] = arr[i - steps];
        }

        // Copy elements from temp array back to original array
        for (int i = 0; i < steps; i++) {
            arr[i] = temp[i];
        }
    }
}
