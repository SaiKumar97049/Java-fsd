package SaiKumarNaik;

class Panipuri {
    int data;
    Panipuri next;

    public Panipuri(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Panipuri head;

    public CircularLinkedList() {
        head = null;
    }

    public void insert(int data) {
        Panipuri newPanipuri = new Panipuri(data);

        if (head == null) {
            newPanipuri.next = newPanipuri;
            head = newPanipuri;
        } else if (data <= head.data) {
            Panipuri temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newPanipuri;
            newPanipuri.next = head;
            head = newPanipuri;
        } else {
            Panipuri temp = head;
            while (temp.next != head && temp.next.data < data) {
                temp = temp.next;
            }
            newPanipuri.next = temp.next;
            temp.next = newPanipuri;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Panipuri temp = head;
        do {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        } while (temp != head);

        System.out.println();
    }

    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();

        list.insert(90);
        list.insert(60);
        list.insert(77);
        list.insert(68);
        list.insert(28);

        System.out.println("Original Circular Linked List:");
        list.display();

        int newData = 88;
        list.insert(newData);

        System.out.println("Circular Linked List after inserting " + newData + ":");
        list.display();
    }
}
