/**
 * 
 */
/**
 * 
 */
module Panipuri {
}