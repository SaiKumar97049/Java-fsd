package SaiKumarNaik;

import java.util.Arrays;

public class FourthSmallestElement {

    public static void main(String[] args) {
        int[] arr = {12, 3, 1, 6, 8, 10, 3, 4};

        int fourthSmallest = findFourthSmallest(arr);

        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }

    public static int findFourthSmallest(int[] arr) {
        Arrays.sort(arr);
        int count = 1;
        int fourthSmallest = arr[0];

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > fourthSmallest) {
                fourthSmallest = arr[i];
                count++;
            }

            if (count == 4) {
                break;
            }
        }

        return fourthSmallest;
    }
}
