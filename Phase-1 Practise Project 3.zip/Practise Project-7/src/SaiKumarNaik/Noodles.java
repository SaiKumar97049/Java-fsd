package SaiKumarNaik;

class Noodles {
    int data;
    Noodles next;
    Noodles prev;

    public Noodles(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}

class DoublyLinkedList {
    Noodles head;

    public void insert(int data) {
        Noodles newNoodles = new Noodles(data);

        if (head == null) {
            head = newNoodles;
        } else {
            newNoodles.next = head;
            head.prev = newNoodles;
            head = newNoodles;
        }
    }

    public void traverseForward() {
        System.out.println("Traversing in forward direction:");
        Noodles temp = head;
        while (temp != null) {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        }
        System.out.println("null");
    }

    public void traverseBackward() {
        System.out.println("Traversing in backward direction:");
        Noodles temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        while (temp != null) {
            System.out.print(temp.data + " -> ");
            temp = temp.prev;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();

        list.insert(60);
        list.insert(70);
        list.insert(80);
        list.insert(90);
        list.insert(100);

        list.traverseForward();
        list.traverseBackward();
    }
}
