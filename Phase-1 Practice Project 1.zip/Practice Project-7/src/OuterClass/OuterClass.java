package OuterClass;

class OuterClass {
    private int outerVar = 10;

    // Member Inner Class
    class MemberInner {
        public void display() {
            System.out.println("Value of outerVar from MemberInner: " + outerVar);
        }
    }

    // Static Inner Class
    static class StaticInner {
        public void display() {
            System.out.println("This is a static inner class");
        }
    }

    // Method with Local Inner Class
    public void localInnerDemo() {
        class LocalInner {
            public void display() {
                System.out.println("This is a local inner class");
            }
        }
        LocalInner localInner = new LocalInner();
        localInner.display();
    }

    // Anonymous Inner Class
    interface Anonymous {
        void display();
    }

    public void anonymousInnerDemo() {
        Anonymous anonymous = new Anonymous() {
            public void display() {
                System.out.println("This is an anonymous inner class");
            }
        };
        anonymous.display();
    }
}