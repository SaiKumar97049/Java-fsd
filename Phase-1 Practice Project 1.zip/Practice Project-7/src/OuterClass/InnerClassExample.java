package OuterClass;

public class InnerClassExample {
    public static void main(String[] args) {
        OuterClass outer = new OuterClass();

        // Creating and using Member Inner Class
        OuterClass.MemberInner memberInner = outer.new MemberInner();
        memberInner.display();

        // Creating and using Static Inner Class
        OuterClass.StaticInner staticInner = new OuterClass.StaticInner();
        staticInner.display();

        // Using Local Inner Class
        outer.localInnerDemo();

        // Using Anonymous Inner Class
        outer.anonymousInnerDemo();
    }
}
