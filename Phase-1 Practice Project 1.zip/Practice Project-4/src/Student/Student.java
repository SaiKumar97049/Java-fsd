package Student;

public class Student {
    private String name;
    private int age;

    // Default Constructor
    public Student() {
        this.name = "Unknown";
        this.age = 0;
    }

    // Parameterized Constructor
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Constructor Chaining
    public Student(String name) {
        this(name, 0); // Calls the parameterized constructor with age set to 0
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
