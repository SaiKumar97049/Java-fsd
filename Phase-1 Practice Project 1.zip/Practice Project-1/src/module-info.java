/**
 * 
 */
/**
 * 
 */
module TypeCastingExample {
}