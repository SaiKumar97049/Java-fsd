package TypeCastingExample;

public class TypeCastingExample {
    public static void main(String[] args) {
        // Implicit Type Casting
        int intValue = 100;
        double doubleValue = intValue; // Implicit casting from int to double
        System.out.println("Implicit Casting: int to double -> " + doubleValue);

        // Explicit Type Casting
        double doubleValue2 = 123.45;
        int intValue2 = (int) doubleValue2; // Explicit casting from double to int
        System.out.println("Explicit Casting: double to int -> " + intValue2);
    }
}
