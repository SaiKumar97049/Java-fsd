package RegularExpression;

import java.util.regex.*;

public class RegularExpression {
    public static void main(String[] args) {
        // Regular expression pattern to match a date in the format dd/mm/yyyy
        String datePattern = "\\d{2}/\\d{2}/\\d{4}";

        // String to test against the regular expression
        String testString = "Today's date is 11/09/2023.";

        // Pattern and Matcher objects
        Pattern pattern = Pattern.compile(datePattern);
        Matcher matcher = pattern.matcher(testString);

        // Find the first match
        if (matcher.find()) {
            System.out.println("Date found: " + matcher.group());
        } else {
            System.out.println("No date found.");
        }
    }
}
