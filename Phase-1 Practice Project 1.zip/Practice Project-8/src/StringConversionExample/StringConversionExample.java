package StringConversionExample;

public class StringConversionExample {
    public static void main(String[] args) {
        // Create a string
        String str = "Hello, World!";

        // Convert string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(str);

        // Convert string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(str);

        // Display the converted objects
        System.out.println("Original String: " + str);
        System.out.println("StringBuffer: " + stringBuffer);
        System.out.println("StringBuilder: " + stringBuilder);
    }
}
