package MethodExample;

public class MethodExample {

    // Method with no parameters
    public void methodWithNoParameters() {
        System.out.println("This is a method with no parameters");
    }

    // Method with parameters
    public void methodWithParameters(int num1, int num2) {
        int sum = num1 + num2;
        System.out.println("Sum of " + num1 + " and " + num2 + " is: " + sum);
    }

    // Method with return value
    public int methodWithReturnValue(int num1, int num2) {
        return num1 * num2;
    }

    // Method with variable number of arguments (varargs)
    public void methodWithVarargs(String... strings) {
        System.out.println("Received " + strings.length + " arguments:");
        for (String str : strings) {
            System.out.println(str);
        }
    }

    public static void main(String[] args) {
        MethodExample example = new MethodExample();

        // Calling a method with no parameters
        example.methodWithNoParameters();

        // Calling a method with parameters
        example.methodWithParameters(5, 3);

        // Calling a method with return value
        int product = example.methodWithReturnValue(4, 7);
        System.out.println("Product: " + product);

        // Calling a method with varargs
        example.methodWithVarargs("apple", "banana", "cherry");
    }
}
