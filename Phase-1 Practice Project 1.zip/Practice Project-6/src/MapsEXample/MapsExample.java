package MapsEXample;

import java.util.*;

public class MapsExample {
    public static void main(String[] args) {
        // HashMap
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Sai Kumar", 25);
        hashMap.put("Nazma", 30);
        hashMap.put("Kajal", 35);

        // LinkedHashMap
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("One", 1);
        linkedHashMap.put("Two", 2);
        linkedHashMap.put("Three", 3);

        // TreeMap
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("January", 1);
        treeMap.put("February", 2);
        treeMap.put("March", 3);

        // Print HashMap
        System.out.println("HashMap:");
        for (String key : hashMap.keySet()) {
            System.out.println(key + " -> " + hashMap.get(key));
        }

        // Print LinkedHashMap
        System.out.println("\nLinkedHashMap:");
        for (String key : linkedHashMap.keySet()) {
            System.out.println(key + " -> " + linkedHashMap.get(key));
        }

        // Print TreeMap
        System.out.println("\nTreeMap:");
        for (String key : treeMap.keySet()) {
            System.out.println(key + " -> " + treeMap.get(key));
        }
    }
}
