package PublicClass;

//Public class with public method
public class PublicClass {
 public void publicMethod() {
     System.out.println("This is a public method");
 }
}

//Default class with default method
class DefaultClass {
 void defaultMethod() {
     System.out.println("This is a default method");
 }
}

//Class with private members
class PrivateClass {
 private int privateVariable = 100;

 private void privateMethod() {
     System.out.println("This is a private method");
 }

 public void accessPrivateMembers() {
     System.out.println("Accessing private variable: " + privateVariable);
     privateMethod();
 }
}

//Class with protected method
class ProtectedClass {
 protected void protectedMethod() {
     System.out.println("This is a protected method");
 }
}
