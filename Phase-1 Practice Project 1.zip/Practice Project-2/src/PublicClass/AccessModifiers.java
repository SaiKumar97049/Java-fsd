package PublicClass;

public class AccessModifiers {
	 public static void main(String[] args) {
	     // Using public access modifier
	     PublicClass publicObj = new PublicClass();
	     publicObj.publicMethod();

	     // Using default access modifier
	     DefaultClass defaultObj = new DefaultClass();
	     defaultObj.defaultMethod();

	     // Using private access modifier
	     PrivateClass privateObj = new PrivateClass();
	     privateObj.accessPrivateMembers();

	     // Using protected access modifier
	     ProtectedClass protectedObj = new ProtectedClass();
	     protectedObj.protectedMethod();
	 }
	}