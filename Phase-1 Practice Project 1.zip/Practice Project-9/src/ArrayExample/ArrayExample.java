package ArrayExample;

public class ArrayExample {
    public static void main(String[] args) {
        // Declaration and initialization of an integer array
        int[] intArray = {1, 2, 3, 4, 5};

        // Accessing elements of the array
        System.out.println("Elements of intArray:");
        for (int i = 0; i < intArray.length; i++) {
            System.out.print(intArray[i] + " ");
        }
        System.out.println();

        // Declaration and initialization of a string array
        String[] stringArray = {"apple", "banana", "cherry"};

        // Accessing elements of the array
        System.out.println("\nElements of stringArray:");
        for (int i = 0; i < stringArray.length; i++) {
            System.out.print(stringArray[i] + " ");
        }
        System.out.println();

        // Multi-dimensional array
        int[][] multiArray = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

        // Accessing elements of the multi-dimensional array
        System.out.println("\nElements of multiArray:");
        for (int i = 0; i < multiArray.length; i++) {
            for (int j = 0; j < multiArray[i].length; j++) {
                System.out.print(multiArray[i][j] + " ");
            }
            System.out.println();
        }
    }
}
