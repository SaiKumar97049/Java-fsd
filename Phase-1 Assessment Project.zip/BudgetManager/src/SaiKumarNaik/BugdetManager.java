package SaiKumarNaik;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.LocalDate;
import java.util.Scanner;

@SuppressWarnings("unused")
class Expense {
    private LocalDate date;
    private String category;
    private double amount;
    private String description;

    public Expense(LocalDate date, String category, double amount, String description) {
        this.date = date;
        this.category = category;
        this.amount = amount;
        this.description = description;
    }
    
//    public String toString() {
//        return date + "\t" + category + "\t\t" + amount + "\t\t" + description + "\n";
//    }

    public LocalDate getDate() {
        return date;
    }

    public String getCategory() {
        return category;
    }

    public double getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }
}

public class BugdetManager {
    private static double monthlyBudget = 0;
    private static boolean budgetSet = false;
    @SuppressWarnings("unused")
	private static String password = "default";
    private static List<Expense> expenseList = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        if (!login(scanner)) {
            System.out.println("Login failed. Exiting Budget Manager. Goodbye!");
            scanner.close();
            System.exit(0);
        }

        while (true) {
            System.out.println("\nBudget Manager Menu:");
            System.out.println("1. Set Monthly Budget");
            System.out.println("2. Record Expense");
            System.out.println("3. View Budget Log");
            System.out.println("4. Change Password");
            System.out.println("5. Logout and Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    setMonthlyBudget(scanner);
                    break;

                case 2:
                    recordExpense(scanner);
                    break;

                case 3:
                    viewBudgetLog(scanner);
                    break;

                case 4:
                    changePassword(scanner);
                    break;

                case 5:
                    System.out.println("Logging out. Goodbye!");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private static boolean login(Scanner scanner) {
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();

        System.out.print("Enter your password: ");
        String enteredPassword = scanner.nextLine();

        if (username.equals("saikumar") && enteredPassword.equals("Sk786")) {
            System.out.println("Login successful. Welcome, " + username + "!");
            return true;
        } else {
            System.out.println("Login failed. Incorrect username or password.");
            return false;
        }
    }

    private static void setMonthlyBudget(Scanner scanner) {
        if (budgetSet) {
            System.out.print("Monthly budget is already set. Do you want to update it? (Y: YES | N: No)");
            char choice = scanner.next().charAt(0);
            scanner.nextLine();
            if (choice == 'Y' || choice == 'y') {
                System.out.print("Enter your updated monthly budget: $");
                monthlyBudget = scanner.nextDouble();
                System.out.println("Your Monthly Budget Has Been Updated Successfully.");
            }
        } else {
            System.out.print("Enter your monthly budget: $");
            monthlyBudget = scanner.nextDouble();
            System.out.println("Your Monthly Budget Has Been Updated Successfully.");
            budgetSet = true;
        }
    }

    private static void recordExpense(Scanner scanner) {
        System.out.println("\nChoose the Expense Category -");
        System.out.println("1. Clothes");
        System.out.println("2. Electricity Bill");
        System.out.println("3. Exam Fees");
        System.out.println("4. Food");
        System.out.println("5. Fuel");
        System.out.println("6. House Rent");
        System.out.println("7. Travelling");
        System.out.println("8. Other");
        System.out.println("9. Go To Previous Menu");
        int option = scanner.nextInt();
        scanner.nextLine();

        switch(option){
		case 1:
			LocalDate date = LocalDate.now();
			String category ="Clothes";
			String description =category;
			System.out.print("Enter expense amount: $");
			double amount = scanner.nextDouble();
			scanner.nextLine();
			System.out.print("Enter your password: ");
			String enteredPassword = scanner.nextLine();
			if(enteredPassword.equals("Sk786")) {
				Expense expense = new Expense(date, category, amount, description);
				expenseList.add(expense);
				System.out.println("Expense recorded successfully.");
				break;
			}
			else
			{
				System.out.println("Expense Recorded is Unsuccessfull. Incorrect password.");
				break;
			}
		case 2:
			date = LocalDate.now();
			category ="Electricity Bill";
			description =category;
			System.out.print("Enter expense amount: $");
			amount = scanner.nextDouble();
			scanner.nextLine();
			System.out.print("Enter your password: ");
			enteredPassword = scanner.nextLine();
			if(enteredPassword.equals("Sk786")) {
				Expense expense = new Expense(date, category, amount, description);
				expenseList.add(expense);
				System.out.println("Expense recorded successfully.");
				break;
			}
			else
			{
				System.out.println("Expense Recorded is Unsuccessfull. Incorrect password.");
				break;
			}
		case 3:
			date = LocalDate.now();
			category ="Exam Fees";
			description =category;
			System.out.print("Enter expense amount: $");
			amount = scanner.nextDouble();
			scanner.nextLine();
			System.out.print("Enter your password: ");
			enteredPassword = scanner.nextLine();
			if(enteredPassword.equals("Sk786")) {
				Expense expense = new Expense(date, category, amount, description);
				expenseList.add(expense);
				System.out.println("Expense recorded successfully.");
				break;
			}
			else
			{
				System.out.println("Expense Recorded is Unsuccessfull. Incorrect password.");
				break;
			}
		case 4:
			date = LocalDate.now();
			category ="Food";
			description =category;
			System.out.print("Enter expense amount: $");
			amount = scanner.nextDouble();
			scanner.nextLine();
			System.out.print("Enter your password: ");
			enteredPassword = scanner.nextLine();
			if(enteredPassword.equals("Sk786")) {
				Expense expense = new Expense(date, category, amount, description);
				expenseList.add(expense);
				System.out.println("Expense recorded successfully.");
				break;
			}
			else
			{
				System.out.println("Expense Recorded is Unsuccessfull. Incorrect password.");
				break;
			}
		case 5:
			date = LocalDate.now();
			category ="Fuel";
			description =category;
			System.out.print("Enter expense amount: $");
			amount = scanner.nextDouble();
			scanner.nextLine();
			System.out.print("Enter your password: ");
			enteredPassword = scanner.nextLine();
			if(enteredPassword.equals("Sk786")) {
				Expense expense = new Expense(date, category, amount, description);
				expenseList.add(expense);
				System.out.println("Expense recorded successfully.");
				break;
			}
			else
			{
				System.out.println("Expense Recorded is Unsuccessfull. Incorrect password.");
				break;
			}
		case 6:
			date = LocalDate.now();
			category ="House Rent";
			description =category;
			System.out.print("Enter expense amount: $");
			amount = scanner.nextDouble();
			scanner.nextLine();
			System.out.print("Enter your password: ");
			enteredPassword = scanner.nextLine();
			if(enteredPassword.equals("Sk786")) {
				Expense expense = new Expense(date, category, amount, description);
				expenseList.add(expense);
				System.out.println("Expense recorded successfully.");
				break;
			}
			else
			{
				System.out.println("Expense Recorded is Unsuccessfull. Incorrect password.");
				break;
			}
		case 7:
			date = LocalDate.now();
			category ="Travelling";
			description =category;
			System.out.print("Enter expense amount: $");
			amount = scanner.nextDouble();
			scanner.nextLine();
			System.out.print("Enter your password: ");
			enteredPassword = scanner.nextLine();
			if(enteredPassword.equals("Sk786")) {
				Expense expense = new Expense(date, category, amount, description);
				expenseList.add(expense);
				System.out.println("Expense recorded successfully.");
				break;
			}
			else
			{
				System.out.println("Expense Recorded is Unsuccessfull. Incorrect password.");
				break;
			}
		case 8:
			date = LocalDate.now();
			category ="Other";
			description =category;
			scanner.nextLine();
			System.out.print("Enter expense amount: $");
			amount = scanner.nextDouble();
			scanner.nextLine();
			System.out.print("Enter your password: ");
			enteredPassword = scanner.nextLine();
			if(enteredPassword.equals("Sk786")) {
				Expense expense = new Expense(date, category, amount, description);
				expenseList.add(expense);
				System.out.println("Expense recorded successfully.");
				break;
			}
			else
			{
				System.out.println("Expense Recorded is Unsuccessfull. Incorrect password.");
				break;
			}
		case 9:
			break;
		default:
			System.out.println("Invalid Option Check the option and try again");

		}
	}

    private static void viewBudgetLog(Scanner scanner) {
        System.out.println("\nBudget Log Menu:");
        System.out.println("1. Date-wise Log");
        System.out.println("2. Month-wise Log");
        System.out.println("3. Total Budget");
        System.out.println("4. Delete Budgetary Log");
        System.out.print("Select the budget log you want to display: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                viewDateWiseLog(scanner);
                break;
            case 2:
                viewMonthWiseLog(scanner);
                break;
            case 3:
                viewTotalBudget();
                break;
            case 4:
                deleteBudgetLog(scanner);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
    }

    private static void viewDateWiseLog(Scanner scanner) {
        System.out.print("Enter the date in DD-MM-YYYY format for which you want to display the budgetary logs: ");
        String dateStr = scanner.nextLine();
        LocalDate targetDate = LocalDate.parse(dateStr, java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        System.out.println("\nDate-wise Log:");
        System.out.println("+----+------------+------------------+---------+---------------------+");
        System.out.println("| ID |    DATE    |    CATEGORY      | AMOUNT  |     DESCRIPTION     |");
        System.out.println("+----+------------+------------------+---------+---------------------+");
        int id = 1;

        for (Expense expense : expenseList) {
            if (expense.getDate().isEqual(targetDate)) {
                System.out.printf("| %-2d | %10s | %-16s | %7.2f | %-19s |\n",
                        id, expense.getDate(), expense.getCategory(), expense.getAmount(), expense.getDescription());
                id++;
            }
        }

        System.out.println("+----+------------+------------------+---------+---------------------+");
    }

    private static void viewMonthWiseLog(Scanner scanner) {
        System.out.print("Enter the month number between 1 to 12 for which you want to display the budgetary logs: ");
        int month = scanner.nextInt();
        scanner.nextLine();

        System.out.println("\nMonth-wise Log:");
        System.out.println("+----+------------+------------------+---------+---------------------+");
        System.out.println("| ID |    DATE    |    CATEGORY      | AMOUNT  |     DESCRIPTION     |");
        System.out.println("+----+------------+------------------+---------+---------------------+");
        int id = 1;

        for (Expense expense : expenseList) {
            if (expense.getDate().getMonthValue() == month) {
                System.out.printf("| %-2d | %10s | %-16s | %7.2f | %-19s |\n",
                        id, expense.getDate(), expense.getCategory(), expense.getAmount(), expense.getDescription());
                id++;
            }
        }

        System.out.println("+----+------------+------------------+---------+---------------------+");
    }

	private static void viewTotalBudget() {
        System.out.println("MONTHLY BUDGET:");
        System.out.println(monthlyBudget);

        double totalSpent = 0;
        for (Expense expense : expenseList) {
            totalSpent += expense.getAmount();
        }

        double currentBudget = monthlyBudget - totalSpent;
        System.out.println("CURRENT BUDGET:");
        System.out.println(currentBudget);

        System.out.println("TOTAL SPENDING:");
        System.out.println(totalSpent);
    }
    private static void deleteBudgetLog(Scanner scanner) {
        System.out.print("Enter the month number between 1 to 12 for deleting the log: ");
        int monthToDelete = scanner.nextInt();
        scanner.nextLine();

        List<Expense> expensesToDelete = new ArrayList<>();

        for (Expense expense : expenseList) {
            if (expense.getDate().getMonthValue() == monthToDelete) {
                expensesToDelete.add(expense);
            }
        }

        if (!expensesToDelete.isEmpty()) {
            System.out.println("Budgetary log for month " + monthToDelete + " has been deleted successfully.");
            expenseList.removeAll(expensesToDelete);
        } else {
            System.out.println("No budgetary log found for the specified month.");
        }
    }


    private static void changePassword(Scanner scanner) {
        System.out.print("Enter your old password: ");
        String oldPassword = scanner.nextLine();

        if (!oldPassword.equals("Sk786")) {
            System.out.println("Incorrect old password. Password change failed.");
            return;
        }

        System.out.print("Enter your new password: ");
        String newPassword = scanner.nextLine();

        System.out.print("Confirm your new password: ");
        String confirmedNewPassword = scanner.nextLine();

        if (!newPassword.equals(confirmedNewPassword)) {
            System.out.println("New password and confirmation do not match. Password change failed.");
        } else if (newPassword.equals(oldPassword)) {
            System.out.println("Old Password and New Password Must be Different");
        } else {
            password = newPassword;
            System.out.println("Password changed successfully.");
        }
        //scanner.close();
    }
}