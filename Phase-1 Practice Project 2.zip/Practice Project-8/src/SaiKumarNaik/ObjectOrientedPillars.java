package SaiKumarNaik;

//Class definition for a Car
class Car {
 private String make;
 private String model;
 private int year;

 // Constructor to initialize the Car object
 public Car(String make, String model, int year) {
     this.make = make;
     this.model = model;
     this.year = year;
 }

 // Getter methods for make, model, and year
 public String getMake() {
     return make;
 }

 public String getModel() {
     return model;
 }

 public int getYear() {
     return year;
 }

 // Method to display information about the car
 public void displayInfo() {
     System.out.println("Make: " + make);
     System.out.println("Model: " + model);
     System.out.println("Year: " + year);
 }
}

//Inheritance: Creating a subclass SportsCar that extends Car
class SportsCar extends Car {
 private boolean turboCharged;

 // Constructor to initialize SportsCar object
 public SportsCar(String make, String model, int year, boolean turboCharged) {
     super(make, model, year);
     this.turboCharged = turboCharged;
 }

 // Polymorphism: Overriding displayInfo() for SportsCar
 @Override
 public void displayInfo() {
     super.displayInfo();
     System.out.println("Turbo Charged: " + turboCharged);
 }
}


public class ObjectOrientedPillars {
    public static void main(String[] args) {
        // Creating objects
        Car car1 = new Car("Toyota", "Camry", 2023);
        SportsCar sportsCar1 = new SportsCar("Ferrari", "488 GTB", 2023, true);

        // Accessing object properties and methods
        System.out.println("Car 1 Information:");
        car1.displayInfo();
        System.out.println("\nSports Car 1 Information:");
        sportsCar1.displayInfo();

        // Abstraction: Using getters to access private variables
        System.out.println("\nMake of Sports Car 1: " + sportsCar1.getMake());
        System.out.println("Year of Sports Car 1: " + sportsCar1.getYear());
    }
}
