/**
 * 
 */
/**
 * 
 */
module ObjectOrientedPillars {
}