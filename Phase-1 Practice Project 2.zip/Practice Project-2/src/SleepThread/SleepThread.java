package SleepThread;

class SleepThread extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("SleepThread: " + i);
            try {
                Thread.sleep(1000); // Sleep for 1 second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class WaitThread extends Thread {
    private final Object lock;

    public WaitThread(Object lock) {
        this.lock = lock;
    }

    public void run() {
        synchronized (lock) {
            System.out.println("WaitThread waiting...");
            try {
                lock.wait(); // Waits until notified
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("WaitThread resumed.");
        }
    }
    
    public static void main(String[] args) {
        // Example of using sleep()
        SleepThread sleepThread = new SleepThread();
        sleepThread.start();

        // Example of using wait() and notify()
        Object lock = new Object();
        WaitThread waitThread = new WaitThread(lock);

        synchronized (lock) {
            waitThread.start();
            try {
                Thread.sleep(2000); // Sleep for 2 seconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("Main thread notifying...");
            lock.notify(); // Notifying the waiting thread
        }
    }
}

