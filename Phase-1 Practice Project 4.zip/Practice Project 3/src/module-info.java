/**
 * 
 */
/**
 * 
 */
module ExponentialSearch {
}